import { getActionDefinition, canPayCost, getAvailableActions } from "@/engine/actions";
import { resolveExchange } from "@/engine/resolver";
import { getCard } from "@/data/cards";
import { getCharacter } from "@/data/characters";
import { createRng, shuffle, timeSeed } from "@/systems/rng";
import type { BattleState, ChosenAction, CombatantState, QteResult } from "@/types";

function createCombatant(characterId: string, deck: string[], rng: () => number): CombatantState {
  const character = getCharacter(characterId);
  const drawPile = shuffle(rng, deck);
  return {
    characterId,
    hp: character.hp,
    maxHp: character.hp,
    energy: 3,
    maxEnergy: 10,
    mana: 3,
    maxMana: 10,
    superGauge: 0,
    superTurnsLeft: 0,
    ultimateUsed: false,
    hand: drawPile.splice(0, 5),
    drawPile,
    discardPile: [],
    statuses: [],
    cooldowns: {},
    recentDamageTaken: [],
    perfectStreak: 0,
    nextAttackBonusPercent: 0,
    vars: {},
  };
}

function copyCombatants(state: BattleState): BattleState["combatants"] {
  return state.combatants.map((fighter) => ({
    ...fighter,
    hand: [...fighter.hand],
    drawPile: [...fighter.drawPile],
    discardPile: [...fighter.discardPile],
    statuses: fighter.statuses.map((status) => ({ ...status })),
    cooldowns: { ...fighter.cooldowns },
    recentDamageTaken: [...fighter.recentDamageTaken],
    vars: { ...fighter.vars },
  })) as BattleState["combatants"];
}

export function createBattleState(
  playerCharacterId: string,
  enemyCharacterId?: string,
  playerDeck?: string[],
  seed = timeSeed(),
): BattleState {
  const player = getCharacter(playerCharacterId);
  const opponents = ["kael", "lyra", "vorn", "sylphe", "mordrak", "aiko", "echo", "nyra"]
    .filter((id) => id !== player.id);
  const enemyId = enemyCharacterId ?? opponents[seed % opponents.length];
  const enemy = getCharacter(enemyId);
  const playerDeckIds = playerDeck ?? player.recommendedDeck;
  for (const id of playerDeckIds) {
    const card = getCard(id);
    if (card.characterId && card.characterId !== player.id) {
      throw new Error(`Le deck de ${player.id} contient la signature incompatible ${id}.`);
    }
  }
  const rng = createRng(seed);
  return {
    phase: "ATTACK_SELECT",
    attackerIndex: 0,
    combatants: [
      createCombatant(player.id, playerDeckIds, rng),
      createCombatant(enemy.id, enemy.recommendedDeck, rng),
    ],
    turn: 1,
    maxTurns: 20,
    chosenAttack: null,
    chosenDefense: null,
    attackQte: null,
    defenseQte: null,
    history: { attackerActions: [], defenderActions: [] },
    log: [`${player.id} contre ${enemy.id}. Le combat commence.`],
    winner: null,
  };
}

function spend(state: BattleState, index: 0 | 1, action: ChosenAction, defending: boolean): void {
  const fighter = state.combatants[index];
  const definition = getActionDefinition(fighter, action, defending);
  const rangedDiscount = action.kind === "card" && action.cardId
    && getCard(action.cardId).type === "attack-ranged"
    ? fighter.vars.nextRangedCardCostMinus ?? 0
    : 0;
  if (
    fighter.energy < (definition.cost.energy ?? 0)
    || fighter.mana < Math.max(0, (definition.cost.mana ?? 0) - rangedDiscount)
    || fighter.hp <= (definition.cost.hp ?? 0)
  ) {
    throw new Error("Ressources insuffisantes.");
  }
  fighter.energy -= definition.cost.energy ?? 0;
  fighter.mana -= Math.max(0, (definition.cost.mana ?? 0) - rangedDiscount);
  fighter.hp -= definition.cost.hp ?? 0;
  if (rangedDiscount) fighter.vars.nextRangedCardCostMinus = 0;
  if (definition.abilityId) {
    const ability = getCharacter(fighter.characterId);
    fighter.cooldowns[definition.abilityId] =
      (defending ? ability.abilityDefense : ability.abilityAttack).cooldown;
  }
  if (definition.isUltimate) {
    fighter.ultimateUsed = true;
    fighter.superGauge = 0;
  }
  if (action.kind === "card" && action.cardId) {
    const cardIndex = fighter.hand.indexOf(action.cardId);
    if (cardIndex < 0) throw new Error("Cette carte n'est plus dans la main.");
    fighter.hand.splice(cardIndex, 1);
    fighter.discardPile.push(action.cardId);
  }
}

export function chooseAttack(state: BattleState, action: ChosenAction): BattleState {
  if (state.phase !== "ATTACK_SELECT") throw new Error("Ce n'est pas la phase de choix d'attaque.");
  if (!isAvailable(state, state.attackerIndex, action, false)) {
    throw new Error("Cette action n'est pas disponible.");
  }
  if (action.kind === "basic-guard") throw new Error("La Garde ne peut pas être choisie comme attaque.");
  const fighter = state.combatants[state.attackerIndex];
  const definition = getActionDefinition(fighter, action);
  if (action.kind === "card" && definition.cardType === "defense") {
    throw new Error("Une carte défensive ne peut pas être jouée en attaque.");
  }
  if (action.kind === "ultimate" && getCharacter(fighter.characterId).ultimate.mode === "defensive") {
    throw new Error("Cet ultime ne peut être utilisé qu'en défense.");
  }
  const next = { ...state, combatants: copyCombatants(state) };
  spend(next, state.attackerIndex, action, false);
  next.chosenAttack = action;
  next.phase = "DEFENSE_SELECT";
  return next;
}

export function chooseDefense(state: BattleState, action: ChosenAction): BattleState {
  if (state.phase !== "DEFENSE_SELECT") throw new Error("Ce n'est pas la phase de choix de défense.");
  const defenderIndex = state.attackerIndex === 0 ? 1 : 0;
  if (!isAvailable(state, defenderIndex, action, true)) {
    throw new Error("Cette action n'est pas disponible.");
  }
  if (action.kind === "basic-attack") throw new Error("Une attaque ne peut pas être choisie en défense.");
  const fighter = state.combatants[defenderIndex];
  const definition = getActionDefinition(fighter, action, true);
  if (action.kind === "card" && definition.cardType !== "defense") {
    throw new Error("Seules les cartes défensives peuvent être jouées en défense.");
  }
  if (action.kind === "ultimate" && getCharacter(fighter.characterId).ultimate.mode === "offensive") {
    throw new Error("Cet ultime ne peut être utilisé qu'en attaque.");
  }
  const next = { ...state, combatants: copyCombatants(state) };
  spend(next, defenderIndex, action, true);
  next.chosenDefense = action;
  next.phase = "ATTACK_QTE";
  if (actionQteLength(next, false) === 0) {
    return { ...next, phase: "DEFENSE_QTE" };
  }
  return next;
}

function isAvailable(
  state: BattleState,
  fighterIndex: 0 | 1,
  action: ChosenAction,
  defending: boolean,
): boolean {
  return getAvailableActions(state, fighterIndex, defending).some((available) =>
    available.kind === action.kind && available.cardId === action.cardId,
  );
}

export function submitAttackQte(state: BattleState, result: QteResult): BattleState {
  if (state.phase !== "ATTACK_QTE") throw new Error("Le QTE d'attaque n'est pas attendu.");
  const next = { ...state, attackQte: result };
  const defenderIndex = state.attackerIndex === 0 ? 1 : 0;
  if (actionQteLength(next, true) === 0) {
    return resolveExchange({ ...next, phase: "RESOLVE" });
  }
  return { ...next, phase: "DEFENSE_QTE" };
}

export function submitDefenseQte(state: BattleState, result: QteResult): BattleState {
  if (state.phase !== "DEFENSE_QTE") throw new Error("Le QTE de défense n'est pas attendu.");
  return resolveExchange({ ...state, defenseQte: result, phase: "RESOLVE" });
}

export function actionQteLength(
  state: BattleState,
  defending: boolean,
): number {
  const index = defending
    ? state.attackerIndex === 0 ? 1 : 0
    : state.attackerIndex;
  const action = defending ? state.chosenDefense : state.chosenAttack;
  if (!action) return 0;
  const fighter = state.combatants[index];
  const baseLength = getActionDefinition(fighter, action, defending).qte;
  return Math.max(0, baseLength - (fighter.vars.qteMinus ?? 0));
}

export function makeQteResult(grades: QteResult["grades"], zenMode = false): QteResult {
  const perfects = grades.filter((grade) => grade === "perfect").length;
  const goods = grades.filter((grade) => grade === "good").length;
  const misses = grades.length - perfects - goods;
  const allPerfect = grades.length > 0 && perfects === grades.length;
  const multiplier = grades.length === 0
    ? 1
    : Math.min(1, 0.6 + (perfects * 0.4 + goods * 0.2) / grades.length);
  return {
    grades,
    multiplier: zenMode ? 0.85 : allPerfect ? 1.1 : multiplier,
    allPerfect,
    perfects,
    goods,
    misses,
  };
}
