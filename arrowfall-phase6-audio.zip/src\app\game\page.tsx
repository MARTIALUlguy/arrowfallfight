"use client";

import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { actionQteLength, chooseAttack, chooseDefense, createBattleState, makeQteResult, submitAttackQte, submitDefenseQte } from "@/engine/battle";
import { chooseAiAttack, chooseAiDefense, submitAiQte } from "@/engine/ai";
import { getAvailableActions, getEffectiveActionCost } from "@/engine/actions";
import { getCard } from "@/data/cards";
import { getCharacter } from "@/data/characters";
import { STATUSES } from "@/data/statuses";
import { BattleScene } from "@/components/battle/BattleScene";
import { createQteSequence, hasPerfectOnlyModifier, QTE_ARROW_DURATION_MS, QTE_GOOD_WINDOW_MS, QTE_PERFECT_WINDOW_MS } from "@/engine/qte";
import { defaultSettings, loadSave, updateSave } from "@/systems/save";
import { playSound, startMusic, unlockAudio } from "@/systems/audio";
import { validateCharacterDeck } from "@/data/decks";
import { useI18n } from "@/systems/i18n";
import type { BattleState, ChosenAction, Direction, GameSettings, InputGrade, QteResult } from "@/types";
import { getChapter } from "@/data/campaign";
import { CHARACTERS } from "@/data/characters";
import { SURVIVAL_BONUSES, survivalDifficulty, survivalEnemyHpBonus } from "@/data/survival";
import { drawCards } from "@/engine/resolver";
import { useRouter } from "next/navigation";

const ARROWS: Record<Direction, string> = {
  up: "↑",
  right: "→",
  down: "↓",
  left: "←",
};

function GameContent() {
  const { t } = useI18n();
  const router = useRouter();
  const params = useSearchParams();
  const characterId = params.get("character") ?? "kael";
  const mode = params.get("mode") ?? "campaign";
  const requestedChapterId = Number(params.get("chapter") ?? "1");
  const chapterId = Number.isInteger(requestedChapterId)
    && requestedChapterId >= 1
    && requestedChapterId <= 8
    ? requestedChapterId
    : 1;
  const chapter = mode === "campaign" ? getChapter(chapterId) : null;
  const wave = Math.max(1, Number(params.get("wave") ?? "1") || 1);
  const localPvp = mode === "local-pvp";
  const requestedOpponent = params.get("opponent") ?? "";
  const opponentId = localPvp
    ? requestedOpponent
    : chapter?.opponentId ?? CHARACTERS.find((entry) => entry.id !== characterId)?.id ?? "kael";
  const opponentValid = CHARACTERS.some((entry) => entry.id === opponentId);
  const safeOpponentId = opponentValid ? opponentId : "kael";
  const runDifficulty = mode === "campaign" && chapter
    ? chapter.difficulty
    : mode === "survival" ? survivalDifficulty(wave) : null;
  const battleSeed = useMemo(
    () => Array.from(`${mode}:${characterId}:${safeOpponentId}:${chapterId}:${wave}`).reduce(
      (seed, character) => (Math.imul(seed, 31) + character.charCodeAt(0)) >>> 0,
      7,
    ),
    [characterId, mode, safeOpponentId, chapterId, wave],
  );
  const createBattleForRoute = (seed: number) => {
    const save = loadSave();
    const playerCustomDeck = save.customDecks[characterId];
    const survivalDeck = save.survivalRun?.characterId === characterId
      && save.survivalRun.wave === wave
      ? save.survivalRun.deck
      : null;
    const selectedPlayerDeck = survivalDeck ?? playerCustomDeck;
    const playerDeck = selectedPlayerDeck && validateCharacterDeck(characterId, selectedPlayerDeck).ok
      ? selectedPlayerDeck
      : undefined;
    const opponentCustomDeck = save.customDecks[safeOpponentId];
    const enemyDeck = opponentCustomDeck && validateCharacterDeck(safeOpponentId, opponentCustomDeck).ok
      ? opponentCustomDeck
      : undefined;
    const enemyId = mode === "survival"
      ? CHARACTERS.filter((entry) => entry.id !== characterId)[(wave - 1) % (CHARACTERS.length - 1)].id
      : safeOpponentId;
    const enemyBonus = mode === "survival" ? survivalEnemyHpBonus(wave) : 0;
    const nextBattle = createBattleState(
      characterId,
      enemyId,
      playerDeck,
      seed,
      enemyBonus,
      mode === "local-pvp" ? enemyDeck : undefined,
    );
    if (mode === "survival") {
      const run = save.survivalRun;
      const fighter = nextBattle.combatants[0];
      if (run && run.characterId === characterId && run.wave === wave && wave > 1) {
        fighter.hp = Math.min(fighter.maxHp, run.hp);
        fighter.maxHp = run.maxHp;
        fighter.hp = Math.min(fighter.maxHp, run.hp);
        fighter.energy = Math.min(fighter.maxEnergy, run.energy);
        fighter.maxEnergy = run.maxEnergy;
        fighter.energy = Math.min(fighter.maxEnergy, run.energy);
        fighter.mana = Math.min(fighter.maxMana, run.mana);
        fighter.maxMana = run.maxMana;
        fighter.mana = Math.min(fighter.maxMana, run.mana);
        fighter.superGauge = run.superGauge;
        fighter.maxHandSize = run.maxHandSize;
        if (run.lastBonus === "draw" && run.bonusAppliedWave !== wave) drawCards(fighter, 2);
      }
    }
    return nextBattle;
  };
  const [battle, setBattle] = useState<BattleState>(() =>
    createBattleForRoute(battleSeed),
  );
  const [activeBattleSeed, setActiveBattleSeed] = useState(battleSeed);
  const [settings, setSettings] = useState<GameSettings>(() => defaultSettings());
  const aiDifficulty = runDifficulty ?? settings.aiDifficulty;
  const [settingsLoaded, setSettingsLoaded] = useState(false);
  const [sequence, setSequence] = useState<Direction[]>([]);
  const [grades, setGrades] = useState<InputGrade[]>([]);
  const [now, setNow] = useState(0);
  const [arrowStartedAt, setArrowStartedAt] = useState(0);
  const [tutorialOpen, setTutorialOpen] = useState(false);
  const [tutorialStep, setTutorialStep] = useState(0);
  const [musicEnabled, setMusicEnabled] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const qteSessionRef = useRef("");
  const qteLockRef = useRef(false);
  const resultRecordedRef = useRef("");
  const perfectStreakRef = useRef(0);
  const musicControllerRef = useRef<Awaited<ReturnType<typeof startMusic>> | null>(null);
  const routeSeedRef = useRef(battleSeed);
  const player = battle.combatants[0];
  const enemy = battle.combatants[1];
  const playerCharacter = getCharacter(player.characterId);
  const enemyCharacter = getCharacter(enemy.characterId);
  const humanAttacking = localPvp || battle.attackerIndex === 0;
  const humanDefending = localPvp || battle.attackerIndex === 1;
  const attackActorIndex = battle.attackerIndex;
  const defenseActorIndex = battle.attackerIndex === 0 ? 1 : 0;
  const isHumanQte = battle.phase === "ATTACK_QTE" ? humanAttacking : humanDefending;
  const isQtePhase = battle.phase === "ATTACK_QTE" || battle.phase === "DEFENSE_QTE";
  const qteLength = isQtePhase ? actionQteLength(battle, battle.phase === "DEFENSE_QTE") : 0;
  const qteFighter = battle.combatants[
    battle.phase === "DEFENSE_QTE"
      ? battle.attackerIndex === 0 ? 1 : 0
      : battle.attackerIndex
  ];
  const perfectOnly = hasPerfectOnlyModifier(qteFighter);
  const currentArrowElapsed = now === 0 ? 0 : Math.max(0, now - arrowStartedAt);
  const chillMultiplier = qteFighter.statuses.some((status) => status.id === "chill") ? 0.75 : 1;
  const hasteMultiplier = qteFighter.statuses.some((status) => status.id === "haste") ? 1.25 : 1;
  const qteTimeFactor = chillMultiplier * hasteMultiplier;
  const arrowDuration = QTE_ARROW_DURATION_MS * qteTimeFactor;
  const perfectWindow = QTE_PERFECT_WINDOW_MS * qteTimeFactor;
  const goodWindow = QTE_GOOD_WINDOW_MS * qteTimeFactor;
  const arrowTimeLeft = Math.max(0, arrowDuration - currentArrowElapsed);
  const qteTotalTime = qteLength * arrowDuration;
  const qteTimePercent = settings.zenMode
    ? 100
    : qteLength === 0 ? 0 : (arrowTimeLeft / QTE_ARROW_DURATION_MS) * 100;
  const qteActionKey = `${battle.phase}:${battle.turn}:${battle.attackerIndex}:${battle.chosenAttack?.kind}:${battle.chosenAttack?.cardId}:${battle.chosenDefense?.kind}:${battle.chosenDefense?.cardId}`;
  const attackActions = useMemo(
    () => getAvailableActions(battle, attackActorIndex),
    [battle, attackActorIndex],
  );
  const defenseActions = useMemo(
    () => getAvailableActions(battle, defenseActorIndex, true),
    [battle, defenseActorIndex],
  );

  useEffect(() => {
    const save = loadSave();
    setSettings(save.settings);
    setTutorialOpen(!save.tutorialSeen);
    setSettingsLoaded(true);
  }, []);

  useEffect(() => {
    musicControllerRef.current?.setVolume(settings.musicVolume);
  }, [settings.musicVolume]);

  useEffect(() => () => {
    musicControllerRef.current?.stop();
  }, []);

  const toggleMusic = async () => {
    if (musicControllerRef.current) {
      musicControllerRef.current.stop();
      musicControllerRef.current = null;
      setMusicEnabled(false);
      return;
    }
    try {
      musicControllerRef.current = await startMusic(settings.musicVolume);
      setMusicEnabled(true);
      setAudioError(null);
    } catch (error) {
      setAudioError(error instanceof Error ? error.message : t("options.audioError"));
    }
  };

  const recordQteStats = useCallback((result: QteResult) => {
    let streak = perfectStreakRef.current;
    for (const grade of result.grades) {
      streak = grade === "perfect" ? streak + 1 : 0;
    }
    perfectStreakRef.current = streak;
    const save = loadSave();
    updateSave({
      records: {
        ...save.records,
        totalPerfects: save.records.totalPerfects + result.perfects,
        bestPerfectStreak: Math.max(save.records.bestPerfectStreak, streak),
      },
    });
  }, []);

  const closeTutorial = () => {
    setTutorialOpen(false);
    updateSave({ tutorialSeen: true });
  };

  useEffect(() => {
    if (routeSeedRef.current === battleSeed) return;
    routeSeedRef.current = battleSeed;
    setBattle(createBattleForRoute(battleSeed));
    setActiveBattleSeed(battleSeed);
    qteSessionRef.current = "";
    resultRecordedRef.current = "";
  }, [battleSeed]);

  useEffect(() => {
    if (mode !== "survival" || wave <= 1) return;
    const run = loadSave().survivalRun;
    if (
      run?.characterId === characterId
      && run.wave === wave
      && run.lastBonus === "draw"
      && run.bonusAppliedWave !== wave
    ) {
      updateSave({ survivalRun: { ...run, bonusAppliedWave: wave } });
    }
  }, [characterId, mode, wave]);

  useEffect(() => {
    if (localPvp || !settingsLoaded || battle.phase !== "ATTACK_SELECT" || battle.attackerIndex !== 1) return;
    setBattle((current) => chooseAiAttack(current, aiDifficulty));
  }, [battle.phase, battle.attackerIndex, aiDifficulty, settingsLoaded, localPvp]);

  useEffect(() => {
    if (localPvp || !settingsLoaded || battle.phase !== "DEFENSE_SELECT" || battle.attackerIndex !== 0) return;
    setBattle((current) => chooseAiDefense(current, aiDifficulty));
  }, [battle.phase, battle.attackerIndex, aiDifficulty, settingsLoaded, localPvp]);

  useEffect(() => {
    if (!isQtePhase) return;
    if (qteSessionRef.current === qteActionKey) return;
    qteSessionRef.current = qteActionKey;
    qteLockRef.current = false;
    setGrades([]);
    setNow(0);
    const qte = createQteSequence(qteLength, qteFighter, Math.random, settings.zenMode);
    setSequence(qte.directions);
    setArrowStartedAt(performance.now());
    if (qteLength > 0 && !isHumanQte) {
      setBattle((current) => submitAiQte(
        current,
        current.phase === "DEFENSE_QTE",
        aiDifficulty,
      ));
      return;
    }
    if (qteLength === 0) {
      const result = makeQteResult([]);
      setBattle((current) => current.phase === "ATTACK_QTE"
        ? submitAttackQte(current, result)
        : submitDefenseQte(current, result));
    }
  }, [
    battle.phase,
    battle.attackerIndex,
    battle.chosenAttack?.cardId,
    battle.chosenAttack?.kind,
    battle.chosenDefense?.cardId,
    battle.chosenDefense?.kind,
    qteActionKey,
    qteFighter,
    isHumanQte,
    isQtePhase,
    qteLength,
    aiDifficulty,
    settings.zenMode,
  ]);

  useEffect(() => {
    if (battle.phase !== "BATTLE_END" || activeBattleSeed !== battleSeed) return;
    const resultKey = `${mode}:${chapterId}:${wave}:${battle.winner}:${battle.turn}`;
    if (resultRecordedRef.current === resultKey) return;
    resultRecordedRef.current = resultKey;
    const save = loadSave();
    try {
      playSound(battle.winner === 0 ? "victory" : "defeat", settings.sfxVolume);
    } catch (error) {
      setAudioError(error instanceof Error ? error.message : t("options.audioError"));
    }
    const patch: Parameters<typeof updateSave>[0] = {
      records: { ...save.records, totalMatches: save.records.totalMatches + 1 },
    };
    if (mode === "campaign" && chapter && battle.winner === 0) {
      patch.campaign = {
        completedChapters: Array.from(new Set([...save.campaign.completedChapters, chapter.id])).sort((a, b) => a - b),
        unlockedCards: Array.from(new Set([...save.campaign.unlockedCards, ...chapter.unlockCards])),
      };
    }
    if (mode === "survival") {
      patch.records = {
        ...save.records,
        totalMatches: save.records.totalMatches + 1,
        survivalBestWave: Math.max(save.records.survivalBestWave, wave),
      };
      if (battle.winner !== 0) patch.survivalRun = null;
    }
    updateSave(patch);
  }, [battle.phase, battle.winner, battle.turn, mode, chapter, chapterId, wave, activeBattleSeed, battleSeed, settings.sfxVolume, t]);

  const recordGrade = useCallback((grade: InputGrade, currentGrades = grades) => {
    if (qteLockRef.current) return;
    const updated = [...currentGrades, grade];
    setGrades(updated);
    setArrowStartedAt(performance.now());
    if (settings.sfxVolume > 0) {
      void unlockAudio()
        .then(() => playSound(grade, settings.sfxVolume))
        .catch((error: unknown) => {
          setAudioError(error instanceof Error ? error.message : t("options.audioError"));
        });
    }
    if (updated.length !== sequence.length) return;
    qteLockRef.current = true;
    const result: QteResult = makeQteResult(updated, settings.zenMode);
    recordQteStats(result);
    setBattle((current) => current.phase === "ATTACK_QTE"
      ? submitAttackQte(current, result)
      : submitDefenseQte(current, result));
  }, [grades, recordQteStats, sequence.length, settings.sfxVolume, settings.zenMode, t]);

  const pressDirection = useCallback((direction: Direction) => {
    if (!isQtePhase || !isHumanQte || sequence.length === 0 || grades.length >= sequence.length) return;
    const elapsed = performance.now() - arrowStartedAt;
    const correct = sequence[grades.length] === direction;
    const grade: InputGrade = !correct || elapsed > goodWindow
      ? "miss"
      : settings.zenMode || perfectOnly || elapsed <= perfectWindow
        ? "perfect"
        : "good";
    recordGrade(grade);
  }, [
    arrowStartedAt,
    grades.length,
    isHumanQte,
    isQtePhase,
    goodWindow,
    perfectWindow,
    perfectOnly,
    recordGrade,
    sequence,
    settings.zenMode,
  ]);

  useEffect(() => {
    if (!isQtePhase || !isHumanQte || settings.zenMode || qteLength === 0) return;
    const timer = window.setInterval(() => {
      const time = performance.now();
      setNow(time);
      if (time - arrowStartedAt >= arrowDuration) {
        window.clearInterval(timer);
        recordGrade("miss");
      }
    }, 40);
    return () => window.clearInterval(timer);
  }, [arrowDuration, arrowStartedAt, isHumanQte, isQtePhase, qteLength, recordGrade, settings.zenMode]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const direction: Record<string, Direction> = {
        ArrowUp: "up",
        ArrowRight: "right",
        ArrowDown: "down",
        ArrowLeft: "left",
      };
      const mapped = direction[event.key];
      if (!mapped) return;
      event.preventDefault();
      pressDirection(mapped);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [pressDirection]);

  const playAction = (action: ChosenAction, defending: boolean) => {
    if (settings.sfxVolume > 0) {
      void unlockAudio()
        .then(() => playSound("click", settings.sfxVolume))
        .catch((error: unknown) => {
          setAudioError(error instanceof Error ? error.message : t("options.audioError"));
        });
    }
    setBattle((current) => defending
      ? chooseDefense(current, action)
      : chooseAttack(current, action));
  };

  const actionLabel = (action: ChosenAction, defending: boolean, fighterIndex: 0 | 1) => {
    const character = getCharacter(battle.combatants[fighterIndex].characterId);
    if (action.kind === "basic-attack") return t("battle.basicAttack");
    if (action.kind === "basic-guard") return t("battle.basicGuard");
    if (action.kind === "ultimate") return t("battle.ultimate");
    if (action.kind === "ability") {
      return t((defending ? character.abilityDefense : character.abilityAttack).nameKey);
    }
    if (action.kind === "card" && action.cardId) return t(getCard(action.cardId).nameKey);
    return t("battle.noAction");
  };

  const renderActionButton = (
    action: ChosenAction,
    index: number,
    defending: boolean,
    fighterIndex: 0 | 1,
  ) => {
    const fighter = battle.combatants[fighterIndex];
    const character = getCharacter(fighter.characterId);
    const card = action.kind === "card" && action.cardId ? getCard(action.cardId) : null;
    const cost = getEffectiveActionCost(battle, fighterIndex, action, defending);
    const isUltimate = action.kind === "ultimate";
    const ability = action.kind === "ability"
      ? (defending ? character.abilityDefense : character.abilityAttack)
      : null;
    const disabled = battle.phase === "BATTLE_END";
    return (
      <button
        key={`${action.kind}-${action.cardId ?? "base"}-${index}`}
        onClick={() => playAction(action, defending)}
        disabled={disabled}
        className="flex min-h-20 flex-col justify-between rounded-lg border border-night-600 bg-night-800/80 p-3 text-left transition hover:border-neon-blue hover:bg-night-700 disabled:opacity-50"
      >
        <span className="font-display font-semibold">{actionLabel(action, defending, fighterIndex)}</span>
        <span className="mt-2 text-xs text-night-600">
          {card?.descriptionKey ? t(card.descriptionKey) : ability?.descriptionKey ? t(ability.descriptionKey) : ""}
          {cost && Object.keys(cost).length > 0 && (
            <span className="mt-1 block text-neon-blue">
              {cost.energy ? `${t("common.energy")} ${cost.energy} ` : ""}
              {cost.mana ? `${t("common.mana")} ${cost.mana} ` : ""}
              {cost.hp ? `${t("common.hp")} ${cost.hp}` : ""}
            </span>
          )}
          {isUltimate && <span className="mt-1 block text-neon-yellow">{t("battle.superReady")}</span>}
          {ability && (
            <span className="mt-1 block text-night-600">
              {t("select.cooldown", { n: fighter.cooldowns[ability.id] ?? 0 })}
            </span>
          )}
        </span>
      </button>
    );
  };

  const renderFighter = (
    fighter: typeof player,
    character: typeof playerCharacter,
    playerLabel: string,
  ) => (
    <section className="rounded-xl border bg-night-800/50 p-4" style={{ borderColor: `${character.accent}88` }}>
      <div className="mb-3 flex items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold" style={{ color: character.accent }}>
            {t(character.nameKey)}
          </h2>
          <p className="text-xs text-night-600">{playerLabel}</p>
        </div>
        <span className="text-sm">{Math.max(0, fighter.hp)} / {fighter.maxHp} {t("common.hp")}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-night-950">
        <div
          className="h-full transition-all"
          style={{
            width: `${Math.max(0, (fighter.hp / fighter.maxHp) * 100)}%`,
            backgroundColor: character.accent,
          }}
        />
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
        <div>{t("common.energy")}: {fighter.energy}/{fighter.maxEnergy}</div>
        <div>{t("common.mana")}: {fighter.mana}/{fighter.maxMana}</div>
        <div>{t("common.superGauge")}: {fighter.superGauge}%</div>
      </div>
      <p className="mt-3 text-xs text-night-600">
        {t(character.mechanicDescriptionKey)}
      </p>
      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-night-600">
        <span>
          {t(character.abilityAttack.nameKey)} · {t("select.cooldown", {
            n: fighter.cooldowns[character.abilityAttack.id] ?? 0,
          })}
        </span>
        <span>
          {t(character.abilityDefense.nameKey)} · {t("select.cooldown", {
            n: fighter.cooldowns[character.abilityDefense.id] ?? 0,
          })}
        </span>
      </div>
      <div className="mt-3 flex min-h-7 flex-wrap gap-2">
        {fighter.statuses.map((status) => (
          <span
            key={status.id}
            className="rounded-full border px-2 py-1 text-xs"
            style={{ borderColor: STATUSES[status.id].color, color: STATUSES[status.id].color }}
            title={t(STATUSES[status.id].descriptionKey)}
          >
            {t(STATUSES[status.id].nameKey)}{status.stacks > 1 ? ` ×${status.stacks}` : ""}
          </span>
        ))}
      </div>
    </section>
  );

  const phaseLabel = battle.phase === "ATTACK_SELECT"
    ? localPvp
      ? t("pvp.playerTurn", { n: battle.attackerIndex + 1 })
      : humanAttacking ? t("battle.playerAttack") : t("battle.enemyAttack")
    : battle.phase === "DEFENSE_SELECT"
      ? localPvp
        ? t("pvp.playerTurn", { n: defenseActorIndex + 1 })
        : humanDefending ? t("battle.playerDefense") : t("battle.enemyDefense")
      : battle.phase === "BATTLE_END" ? t("battle.gameOver") : t("qte.go");
  const survivalBonusChoices = mode === "survival"
    ? Array.from({ length: 3 }, (_, index) =>
      SURVIVAL_BONUSES[(wave - 1 + index * 2) % SURVIVAL_BONUSES.length],
    )
    : [];

  const continueSurvival = (bonusId: string) => {
    const fighter = battle.combatants[0];
    const existing = loadSave().survivalRun;
    const previousRun = existing?.characterId === characterId && existing.wave === wave
      ? existing
      : null;
    const deck = previousRun?.deck
      ?? (loadSave().customDecks[characterId]
        && validateCharacterDeck(characterId, loadSave().customDecks[characterId]).ok
        ? loadSave().customDecks[characterId]
        : getCharacter(characterId).recommendedDeck);
    const run = {
      characterId,
      wave: wave + 1,
      hp: fighter.hp,
      maxHp: fighter.maxHp,
      energy: fighter.energy,
      maxEnergy: fighter.maxEnergy,
      mana: fighter.mana,
      maxMana: fighter.maxMana,
      superGauge: fighter.superGauge,
      maxHandSize: fighter.maxHandSize,
      deck: [...deck],
      bonuses: [...(previousRun?.bonuses ?? []), bonusId],
      lastBonus: bonusId,
      bonusAppliedWave: 0,
    };
    if (bonusId === "heal") run.hp = Math.min(run.maxHp, run.hp + 25);
    if (bonusId === "max-energy") {
      run.maxEnergy += 3;
      run.energy = Math.min(run.maxEnergy, run.energy + 3);
    }
    if (bonusId === "max-mana") {
      run.maxMana += 3;
      run.mana = Math.min(run.maxMana, run.mana + 3);
    }
    if (bonusId === "hand-size") run.maxHandSize += 1;
    if (bonusId === "super") run.superGauge = Math.min(100, run.superGauge + 20);
    updateSave({ survivalRun: run });
    router.push(`/game?mode=survival&character=${characterId}&wave=${wave + 1}`);
  };

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-6xl flex-col gap-5 px-4 py-6 md:px-8">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="neon-title font-display text-3xl font-bold tracking-widest">{t("app.title")}</h1>
          <p className="mt-1 text-sm text-night-600">
            {localPvp
              ? t("pvp.subtitle")
              : mode === "survival"
                ? `${t("survival.wave", { n: wave })} · ${t(`battle.aiDifficulty.${aiDifficulty}`)}`
                : mode === "campaign" && chapter
                  ? `${t("campaign.chapter", { n: chapter.id })} · ${t(`battle.aiDifficulty.${aiDifficulty}`)}`
                  : `${t("common.turn", { n: battle.turn })} · ${t(`battle.aiDifficulty.${aiDifficulty}`)}`}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => void toggleMusic()}
            aria-pressed={musicEnabled}
            className="rounded-lg border border-night-600 px-3 py-2 text-sm hover:border-neon-blue"
          >
            {musicEnabled ? t("options.stopMusicPreview") : t("options.musicPreview")}
          </button>
          <button
            type="button"
            onClick={() => {
              setTutorialStep(0);
              setTutorialOpen(true);
            }}
            className="rounded-lg border border-night-600 px-3 py-2 text-sm hover:border-neon-blue"
          >
            {t("tutorial.reopen")}
          </button>
          <Link href="/" className="rounded-lg border border-night-600 px-4 py-2 text-sm hover:border-neon-blue">
            ← {t("battle.exit")}
          </Link>
        </div>
      </header>
      {audioError && <p role="alert" className="text-sm text-neon-red">{audioError}</p>}

      <BattleScene
        player={playerCharacter}
        enemy={enemyCharacter}
        turn={battle.turn}
        impactKey={battle.history.attackerActions.length}
      />

      <section className="grid gap-3 md:grid-cols-2">
        {renderFighter(
          player,
          playerCharacter,
          localPvp ? t("common.player1") : t("common.you"),
        )}
        {renderFighter(
          enemy,
          enemyCharacter,
          localPvp ? t("common.player2") : t("common.enemy"),
        )}
      </section>

      <section className="rounded-xl border border-night-700 bg-night-800/40 p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-xl font-semibold">{phaseLabel}</h2>
          <span className="rounded-full border border-neon-blue/50 px-3 py-1 text-xs text-neon-blue">
            {mode}
          </span>
        </div>

        {battle.phase === "BATTLE_END" ? (
          <div className="flex flex-wrap gap-3">
            <p className="w-full text-lg">
              {localPvp
                ? t("pvp.winner", { n: (battle.winner ?? 0) + 1 })
                : battle.winner === 0 ? t("battle.youWin") : t("battle.youLose")}
            </p>
            {mode === "campaign" && chapter && (
              <p className="w-full text-sm text-night-600">
                {t(battle.winner === 0 ? chapter.victoryKey : chapter.defeatKey)}
              </p>
            )}
            {mode === "survival" && battle.winner === 0 && (
              <div className="grid w-full gap-3 sm:grid-cols-3">
                {survivalBonusChoices.map((bonus) => (
                  <button
                    key={bonus.id}
                    type="button"
                    onClick={() => continueSurvival(bonus.id)}
                    className="rounded-lg border border-night-600 bg-night-900 p-4 text-left hover:border-neon-green"
                  >
                    <span className="block font-display font-semibold text-neon-green">{t(bonus.nameKey)}</span>
                    <span className="mt-1 block text-sm text-night-600">{t(bonus.descriptionKey)}</span>
                  </button>
                ))}
              </div>
            )}
            {mode === "survival" && battle.winner !== 0 && (
              <p className="w-full text-sm text-night-600">{t("survival.gameOver")}</p>
            )}
            {mode === "campaign" && battle.winner === 0 && chapter && chapter.id < 8 && (
              <Link href="/campaign" className="rounded-lg bg-neon-blue px-4 py-2 font-semibold text-night-950">
                {t("campaign.nextChapter")}
              </Link>
            )}
            {mode === "campaign" && chapter?.id === 8 && battle.winner === 0 && (
              <Link href="/campaign" className="rounded-lg bg-neon-green px-4 py-2 font-semibold text-night-950">
                {t("campaign.complete")}
              </Link>
            )}
            {mode === "local-pvp" && (
              <Link href="/pvp" className="rounded-lg bg-neon-blue px-4 py-2 font-semibold text-night-950">
                {t("battle.retry")}
              </Link>
            )}
            {mode === "survival" && (
              <Link href="/select?mode=survival" className="rounded-lg bg-neon-blue px-4 py-2 font-semibold text-night-950">
                {t("battle.retry")}
              </Link>
            )}
            <Link href="/" className="rounded-lg border border-night-600 px-4 py-2">
              {t("menu.options")}: {t("battle.exit")}
            </Link>
          </div>
        ) : isQtePhase && isHumanQte ? (
          <div>
            <p className="mb-3 text-sm text-night-600">{t("battle.qteHint")}</p>
            <div className="mb-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
              <span className="text-neon-green">{t("battle.qtePerfectWindow")}: 0–{Math.round(perfectWindow)}ms</span>
              <span className="text-neon-yellow">{t("battle.qteGoodWindow")}: {Math.round(perfectWindow) + 1}–{Math.round(goodWindow)}ms</span>
              <span className="text-neon-red">{t("battle.qteMissWindow")}: {Math.round(goodWindow) + 1}–{Math.round(arrowDuration)}ms</span>
            </div>
            {perfectOnly && <p className="mb-2 text-sm text-neon-yellow">{t("battle.qtePerfectOnly")}</p>}
            {settings.zenMode ? (
              <p className="mb-3 text-sm text-neon-blue">{t("battle.qteZen")}</p>
            ) : (
              <div className="mb-3">
                <div className="mb-1 flex justify-between text-xs text-night-600">
                  <span>{t("battle.qteTimed", { seconds: (arrowTimeLeft / 1000).toFixed(1) })}</span>
                  <span>{t("battle.qteTotalTime", { seconds: Math.ceil(qteTotalTime / 1000) })}</span>
                </div>
                <div className="h-2 overflow-hidden rounded-full bg-night-950">
                  <div
                    className={`h-full transition-[width] duration-75 ${arrowTimeLeft < 250 ? "bg-neon-red" : "bg-neon-blue"}`}
                    style={{ width: `${qteTimePercent}%` }}
                  />
                </div>
              </div>
            )}
            <div className="mb-4 flex flex-wrap gap-2" aria-label="QTE sequence">
              {sequence.map((direction, index) => (
                <span
                  key={`${direction}-${index}`}
                  className={`flex h-11 w-11 items-center justify-center rounded-lg border text-xl ${
                    index < grades.length
                      ? grades[index] === "perfect"
                        ? "border-neon-green text-neon-green"
                        : grades[index] === "good"
                          ? "border-neon-yellow text-neon-yellow"
                          : "border-neon-red text-neon-red"
                      : index === grades.length
                        ? "border-neon-blue bg-neon-blue/10 text-white"
                        : "border-night-600 text-night-600"
                  }`}
                >
                  {ARROWS[direction]}
                </span>
              ))}
            </div>
            <p className="mb-3 text-sm text-night-600" aria-live="polite">
              {t("battle.qteProgress", { done: grades.length, total: sequence.length })}
            </p>
            <div className="grid max-w-sm grid-cols-3 gap-2">
              {(["up", "left", "down", "right"] as Direction[]).map((direction) => (
                <button
                  key={direction}
                  onClick={() => pressDirection(direction)}
                  className={`h-12 rounded-lg border border-night-600 bg-night-900 text-2xl hover:border-neon-blue ${
                    direction === "up" ? "col-start-2" : direction === "left" ? "col-start-1" : direction === "down" ? "col-start-2" : "col-start-3 row-start-2"
                  }`}
                  aria-label={direction}
                >
                  {ARROWS[direction]}
                </button>
              ))}
            </div>
          </div>
        ) : battle.phase === "ATTACK_SELECT" && humanAttacking ? (
          <div>
            <p className="mb-3 text-sm text-night-600">
              {localPvp
                ? t("pvp.playerTurn", { n: attackActorIndex + 1 })
                : t("battle.chooseAttack")}
            </p>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {attackActions.map((action, index) => renderActionButton(action, index, false, attackActorIndex))}
            </div>
            {battle.combatants[attackActorIndex].hand.length === 0 && (
              <p className="mt-3 text-sm text-night-600">{t("battle.handEmpty")}</p>
            )}
          </div>
        ) : battle.phase === "DEFENSE_SELECT" && humanDefending ? (
          <div>
            <p className="mb-3 text-sm text-night-600">
              {localPvp
                ? t("pvp.playerTurn", { n: defenseActorIndex + 1 })
                : t("battle.chooseDefense")}
            </p>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {defenseActions.map((action, index) => renderActionButton(action, index, true, defenseActorIndex))}
            </div>
          </div>
        ) : (
          <p className="text-sm text-night-600">{phaseLabel}…</p>
        )}
      </section>

      <section className="rounded-xl border border-night-700 bg-night-800/30 p-4">
        {(localPvp ? battle.combatants : [player]).map((fighter, fighterIndex) => (
          <div key={fighter.characterId} className="mb-3 last:mb-0">
            <h2 className="mb-2 font-display text-lg font-semibold">
              {localPvp ? t("pvp.player", { n: fighterIndex + 1 }) : t("battle.hand")}
            </h2>
            <div className="flex flex-wrap gap-2">
              {fighter.hand.map((cardId, index) => {
                const card = getCard(cardId);
                return (
                  <span key={`${cardId}-${index}`} className="rounded border border-night-700 px-2 py-1 text-xs text-night-600">
                    {t(card.nameKey)}
                  </span>
                );
              })}
              {fighter.hand.length === 0 && <span className="text-sm text-night-600">—</span>}
            </div>
            <p className="mt-2 text-xs text-night-600">
              {t("battle.drawPile", { n: fighter.drawPile.length })} · {t("battle.discardPile", { n: fighter.discardPile.length })}
            </p>
          </div>
        ))}
      </section>

      <section className="rounded-xl border border-night-700 bg-night-800/30 p-4">
        <h2 className="mb-2 font-display text-lg font-semibold">{t("battle.combatLog")}</h2>
        <ol className="flex flex-col gap-1 text-sm text-night-600">
          {battle.log.slice(-6).map((entry, index) => <li key={`${entry}-${index}`}>{entry}</li>)}
        </ol>
      </section>

      {tutorialOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="battle-tutorial-title"
            className="w-full max-w-lg rounded-2xl border border-neon-blue/70 bg-night-900 p-6 shadow-2xl"
          >
            <p className="mb-2 text-xs uppercase tracking-widest text-neon-blue">
              {tutorialStep + 1} / 5
            </p>
            <h2 id="battle-tutorial-title" className="mb-4 font-display text-2xl font-bold">
              {t("app.title")}
            </h2>
            <p className="min-h-20 leading-relaxed text-night-100">
              {t([
                "tutorial.welcome",
                "tutorial.phases",
                "tutorial.qte",
                "tutorial.super",
                "tutorial.statuses",
              ][tutorialStep])}
            </p>
            <div className="mt-6 flex flex-wrap justify-between gap-2">
              <button
                type="button"
                onClick={closeTutorial}
                className="rounded-lg border border-night-600 px-3 py-2 text-sm text-night-600 hover:text-white"
              >
                {t("tutorial.skip")}
              </button>
              <div className="flex gap-2">
                {tutorialStep > 0 && (
                  <button
                    type="button"
                    onClick={() => setTutorialStep((step) => step - 1)}
                    className="rounded-lg border border-night-600 px-3 py-2 text-sm"
                  >
                    {t("tutorial.previous")}
                  </button>
                )}
                {tutorialStep < 4 ? (
                  <button
                    type="button"
                    onClick={() => setTutorialStep((step) => step + 1)}
                    className="rounded-lg bg-neon-blue px-4 py-2 text-sm font-semibold text-night-950"
                  >
                    {t("tutorial.next")}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={closeTutorial}
                    className="rounded-lg bg-neon-green px-4 py-2 text-sm font-semibold text-night-950"
                  >
                    {t("tutorial.finish")}
                  </button>
                )}
              </div>
            </div>
          </section>
        </div>
      )}
    </main>
  );
}

export default function GamePage() {
  return (
    <Suspense fallback={<main className="p-8 text-center">ARROWFALL</main>}>
      <GameContent />
    </Suspense>
  );
}
