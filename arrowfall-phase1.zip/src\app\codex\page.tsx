"use client";

import Link from "next/link";
import { useI18n } from "@/systems/i18n";
import { ALL_CARDS } from "@/data/cards";
import { CHARACTERS } from "@/data/characters";
import { STATUSES } from "@/data/statuses";

/** Codex — Phase 0 : liste brute des données (rendu riche en Phase 3/4). */
export default function CodexPage() {
  const { t } = useI18n();

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-4xl flex-col gap-8 px-6 py-10">
      <header className="flex items-center justify-between">
        <h1 className="neon-title font-display text-4xl font-bold tracking-widest">
          {t("codex.title")}
        </h1>
        <Link href="/" className="text-sm text-night-600 hover:text-white">
          ← {t("common.back")}
        </Link>
      </header>

      <section>
        <h2 className="mb-3 font-display text-2xl">{t("codex.characters")}</h2>
        <ul className="grid grid-cols-2 gap-2 md:grid-cols-4">
          {CHARACTERS.map((c) => (
            <li
              key={c.id}
              className="rounded-lg border border-night-700 bg-night-800/60 px-3 py-2"
              style={{ borderColor: c.accent }}
            >
              <div className="font-semibold" style={{ color: c.accent }}>
                {t(c.nameKey)}
              </div>
              <div className="text-xs text-night-600">{t(c.titleKey)}</div>
              <div className="text-xs text-night-600">
                {t("common.hp")} {c.hp}
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 className="mb-3 font-display text-2xl">
          {t("codex.cards")} ({ALL_CARDS.length})
        </h2>
        <ul className="grid grid-cols-1 gap-2 md:grid-cols-2">
          {ALL_CARDS.map((card) => (
            <li
              key={card.id}
              className="rounded-lg border border-night-700 bg-night-800/60 px-3 py-2"
            >
              <div className="flex items-baseline justify-between gap-2">
                <span className="font-semibold">{t(card.nameKey)}</span>
                <span className="text-xs uppercase text-night-600">
                  {t(`deck.rarities.${card.rarity}`)}
                </span>
              </div>
              <div className="text-sm text-night-600">{t(card.descriptionKey)}</div>
            </li>
          ))}
        </ul>
      </section>

      <section>
        <h2 className="mb-3 font-display text-2xl">{t("codex.statuses")}</h2>
        <ul className="grid grid-cols-1 gap-2 md:grid-cols-2">
          {Object.values(STATUSES).map((status) => (
            <li
              key={status.id}
              className="rounded-lg border bg-night-800/60 px-3 py-2"
              style={{ borderColor: status.color }}
            >
              <div className="font-semibold" style={{ color: status.color }}>
                {t(status.nameKey)}
              </div>
              <div className="text-sm text-night-600">
                {t(status.descriptionKey)}
              </div>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
