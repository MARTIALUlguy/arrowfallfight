import { getAvailableActions, getActionDefinition } from "@/engine/actions";
import { chooseAttack, chooseDefense, makeQteResult, submitAttackQte, submitDefenseQte } from "@/engine/battle";
import { getCard } from "@/data/cards";
import type { BattleState, ChosenAction, QteResult } from "@/types";
import { createRng, pick } from "@/systems/rng";

function actionScore(state: BattleState, action: ChosenAction, defending: boolean): number {
  if (action.kind === "basic-attack") return 8;
  if (action.kind === "basic-guard") return 8;
  if (action.kind === "ultimate") return 24;
  const fighterIndex = defending
    ? state.attackerIndex === 0 ? 1 : 0
    : state.attackerIndex;
  const definition = getActionDefinition(state.combatants[fighterIndex], action, defending);
  const card = action.kind === "card" && action.cardId ? getCard(action.cardId) : null;
  const damage = definition.effect.damage ?? 0;
  const utility = (definition.effect.heal ?? 0) * 0.6
    + (definition.effect.block ?? 0) * 0.08
    + (definition.effect.shield ?? 0) * 0.7
    + (definition.effect.superGain ?? 0) * 0.12
    + (definition.effect.drawCards ?? 0) * 2;
  const lowHpBonus = state.combatants[fighterIndex].hp < 35 ? utility : 0;
  return damage + utility + lowHpBonus - (card ? 1 : 0);
}

function easyChoice(state: BattleState, defending: boolean, seed: number): ChosenAction {
  const fighterIndex = defending
    ? state.attackerIndex === 0 ? 1 : 0
    : state.attackerIndex;
  const options = getAvailableActions(state, fighterIndex, defending);
  const ranked = [...options].sort((a, b) =>
    actionScore(state, b, defending) - actionScore(state, a, defending),
  );
  const rng = createRng(seed);
  const shortlist = ranked.slice(0, Math.min(3, ranked.length));
  return pick(rng, shortlist);
}

export function chooseEasyAiAttack(state: BattleState): BattleState {
  if (state.attackerIndex !== 1) throw new Error("L'IA n'est pas l'attaquante.");
  const action = easyChoice(state, false, state.turn * 31 + state.combatants[1].hp);
  return chooseAttack(state, action);
}

export function chooseEasyAiDefense(state: BattleState): BattleState {
  if (state.attackerIndex !== 0) throw new Error("L'IA n'est pas la défenseuse.");
  const action = easyChoice(state, true, state.turn * 47 + state.combatants[1].hp);
  return chooseDefense(state, action);
}

export function makeEasyAiQte(state: BattleState, defending: boolean): QteResult {
  const length = getActionDefinition(
    state.combatants[defending ? (state.attackerIndex === 0 ? 1 : 0) : state.attackerIndex],
    defending ? state.chosenDefense! : state.chosenAttack!,
    defending,
  ).qte;
  return makeQteResult(Array.from({ length }, () => "good" as const));
}

export function submitEasyAiQte(state: BattleState, defending: boolean): BattleState {
  const result = makeEasyAiQte(state, defending);
  return defending ? submitDefenseQte(state, result) : submitAttackQte(state, result);
}
