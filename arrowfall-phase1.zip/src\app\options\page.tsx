"use client";

import Link from "next/link";
import { useState } from "react";
import { LangSelector, useI18n } from "@/systems/i18n";
import { loadSave, resetSave, updateSettings } from "@/systems/save";

export default function OptionsPage() {
  const { t } = useI18n();
  const [settings, setSettings] = useState(() => loadSave().settings);
  const [message, setMessage] = useState<string | null>(null);

  const patch = (p: Partial<typeof settings>) => {
    const next = { ...settings, ...p };
    setSettings(next);
    updateSettings(p);
  };

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-xl flex-col gap-6 px-6 py-10">
      <header className="flex items-center justify-between">
        <h1 className="neon-title font-display text-4xl font-bold tracking-widest">
          {t("options.title")}
        </h1>
        <Link href="/" className="text-sm text-night-600 hover:text-white">
          ← {t("common.back")}
        </Link>
      </header>

      <section className="flex flex-col gap-4 rounded-xl border border-night-700 bg-night-800/60 p-5">
        <div className="flex items-center justify-between">
          <span>{t("options.language")}</span>
          <LangSelector />
        </div>

        <label className="flex flex-col gap-1">
          <span className="flex justify-between text-sm">
            {t("options.music")}
            <span className="text-night-600">{Math.round(settings.musicVolume * 100)}%</span>
          </span>
          <input
            type="range"
            min={0}
            max={100}
            value={Math.round(settings.musicVolume * 100)}
            onChange={(e) => patch({ musicVolume: Number(e.target.value) / 100 })}
          />
        </label>

        <label className="flex flex-col gap-1">
          <span className="flex justify-between text-sm">
            {t("options.sfx")}
            <span className="text-night-600">{Math.round(settings.sfxVolume * 100)}%</span>
          </span>
          <input
            type="range"
            min={0}
            max={100}
            value={Math.round(settings.sfxVolume * 100)}
            onChange={(e) => patch({ sfxVolume: Number(e.target.value) / 100 })}
          />
        </label>

        <label className="flex items-center justify-between">
          <span>
            {t("options.zenMode")}
            <span className="block text-xs text-night-600">
              {t("options.zenModeDesc")}
            </span>
          </span>
          <input
            type="checkbox"
            checked={settings.zenMode}
            onChange={(e) => patch({ zenMode: e.target.checked })}
            className="h-5 w-5 accent-neon-blue"
          />
        </label>
      </section>

      <section className="flex flex-col gap-3 rounded-xl border border-night-700 bg-night-800/60 p-5">
        <button
          onClick={() => {
            if (window.confirm(t("options.resetConfirm"))) {
              resetSave();
              setSettings(loadSave().settings);
              setMessage(t("options.resetDone"));
            }
          }}
          className="rounded-lg border border-neon-red/60 px-4 py-2 text-neon-red transition-colors hover:bg-neon-red/10"
        >
          {t("options.reset")}
        </button>
        {message && <p className="text-sm text-neon-green">{message}</p>}
      </section>
    </main>
  );
}
