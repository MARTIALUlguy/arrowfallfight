import { getCard } from "@/data/cards";
import { getCharacter } from "@/data/characters";
import type { BattleState, CardEffect, CardType, ChosenAction, CombatantState, ResourceCost } from "@/types";

export interface ActionDefinition {
  effect: CardEffect;
  qte: number;
  cost: ResourceCost;
  cardType?: CardType;
  abilityId?: string;
  isUltimate?: boolean;
}

export function getActionDefinition(
  combatant: CombatantState,
  action: ChosenAction,
  defending = false,
): ActionDefinition {
  const character = getCharacter(combatant.characterId);
  switch (action.kind) {
    case "basic-attack":
      return { effect: { damage: 8 }, qte: 3, cost: {}, cardType: "attack-melee" };
    case "basic-guard":
      return { effect: { block: 40, blockOnPerfect: 55 }, qte: 3, cost: {} };
    case "card": {
      if (!action.cardId) throw new Error("Une action carte doit préciser cardId.");
      const card = getCard(action.cardId);
      if (card.characterId && card.characterId !== combatant.characterId) {
        throw new Error(`La carte ${card.id} n'appartient pas à ${combatant.characterId}.`);
      }
      return { effect: card.effect, qte: card.qte, cost: card.cost, cardType: card.type };
    }
    case "ability": {
      const ability = defending ? character.abilityDefense : character.abilityAttack;
      return {
        effect: ability.effect,
        qte: ability.qte,
        cost: ability.cost,
        abilityId: ability.id,
      };
    }
    case "ultimate": {
      const effect = defending && character.ultimate.mode === "hybrid"
        ? character.ultimate.defensiveEffect ?? character.ultimate.effect
        : character.ultimate.effect;
      return {
        effect,
        qte: character.ultimate.qte,
        cost: {},
        isUltimate: true,
      };
    }
    case "super-activate":
      return { effect: {}, qte: 0, cost: {} };
  }
}

export function canPayCost(combatant: CombatantState, cost: ResourceCost): boolean {
  return combatant.energy >= (cost.energy ?? 0)
    && combatant.mana >= (cost.mana ?? 0)
    && combatant.hp > (cost.hp ?? 0);
}

export function getAvailableActions(
  state: BattleState,
  combatantIndex: 0 | 1,
  defending = false,
): ChosenAction[] {
  const fighter = state.combatants[combatantIndex];
  const character = getCharacter(fighter.characterId);
  const options: ChosenAction[] = [
    { kind: defending ? "basic-guard" : "basic-attack" },
  ];
  const ability = defending ? character.abilityDefense : character.abilityAttack;
  if (
    canPayCost(fighter, ability.cost)
    && (fighter.cooldowns[ability.id] ?? 0) === 0
  ) {
    options.push({ kind: "ability" });
  }

  if (!defending) {
    for (const cardId of fighter.hand) {
      const card = getCard(cardId);
      const discountedMana = card.type === "attack-ranged"
        ? fighter.vars.nextRangedCardCostMinus ?? 0
        : 0;
      if (
        card.type !== "defense"
        && !(fighter.statuses.some((status) => status.id === "silence"))
        && fighter.energy >= (card.cost.energy ?? 0)
        && fighter.mana >= Math.max(0, (card.cost.mana ?? 0) - discountedMana)
        && fighter.hp > (card.cost.hp ?? 0)
      ) {
        options.push({ kind: "card", cardId });
      }
    }
  } else {
    for (const cardId of fighter.hand) {
      const card = getCard(cardId);
      if (
        card.type === "defense"
        && !(fighter.statuses.some((status) => status.id === "silence"))
        && canPayCost(fighter, card.cost)
      ) {
        options.push({ kind: "card", cardId });
      }
    }
  }

  if (fighter.superGauge >= 100 && !fighter.ultimateUsed) {
    if (
      defending ? character.ultimate.mode !== "offensive" : character.ultimate.mode !== "defensive"
    ) {
      options.push({ kind: "ultimate" });
    }
  }
  return options;
}
