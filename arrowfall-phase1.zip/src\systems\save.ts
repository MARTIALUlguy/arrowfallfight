// ============================================================================
// ARROWFALL — Persistance localStorage (clé unique 'arrowfall_save_v1')
// Toutes les lectures sont protégées (SSR / mode privé / JSON corrompu).
// ============================================================================

import type { GameSettings, SaveData } from "@/types";

export const SAVE_KEY = "arrowfall_save_v1";

export function defaultSettings(): GameSettings {
  return {
    language: "fr",
    musicVolume: 0.7,
    sfxVolume: 0.8,
    zenMode: false,
  };
}

export function defaultSave(): SaveData {
  return {
    version: 1,
    settings: defaultSettings(),
    campaign: { completedChapters: [], unlockedCards: [] },
    records: {
      survivalBestWave: 0,
      totalMatches: 0,
      totalPerfects: 0,
      bestPerfectStreak: 0,
    },
    customDecks: {},
    tutorialSeen: false,
  };
}

/** Fusionne un objet brut avec la sauvegarde par défaut (résiste aux anciennes versions). */
function mergeSave(raw: Partial<SaveData>): SaveData {
  const base = defaultSave();
  return {
    version: 1,
    settings: { ...base.settings, ...(raw.settings ?? {}) },
    campaign: { ...base.campaign, ...(raw.campaign ?? {}) },
    records: { ...base.records, ...(raw.records ?? {}) },
    customDecks: { ...(raw.customDecks ?? {}) },
    tutorialSeen: raw.tutorialSeen ?? false,
  };
}

export function loadSave(): SaveData {
  if (typeof window === "undefined") return defaultSave();
  try {
    const raw = window.localStorage.getItem(SAVE_KEY);
    if (!raw) return defaultSave();
    return mergeSave(JSON.parse(raw) as Partial<SaveData>);
  } catch {
    return defaultSave();
  }
}

export function writeSave(data: SaveData): void {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(SAVE_KEY, JSON.stringify(data));
  } catch {
    // Stockage indisponible : le jeu continue sans persistance.
  }
}

/** Met à jour partiellement la sauvegarde et la réécrit. Retourne la nouvelle valeur. */
export function updateSave(patch: Partial<SaveData>): SaveData {
  const next = mergeSave({ ...loadSave(), ...patch });
  writeSave(next);
  return next;
}

export function updateSettings(patch: Partial<GameSettings>): SaveData {
  const current = loadSave();
  return updateSave({ settings: { ...current.settings, ...patch } });
}

export function resetSave(): SaveData {
  const fresh = defaultSave();
  if (typeof window !== "undefined") {
    try {
      window.localStorage.removeItem(SAVE_KEY);
    } catch {
      // ignore
    }
  }
  return fresh;
}

/** Deck personnalisé d'un personnage (null si jamais modifié ou invalide). */
export function getCustomDeck(characterId: string): string[] | null {
  const deck = loadSave().customDecks[characterId];
  return deck && deck.length === 20 ? deck : null;
}

export function setCustomDeck(characterId: string, cards: string[]): SaveData {
  const current = loadSave();
  return updateSave({
    customDecks: { ...current.customDecks, [characterId]: cards },
  });
}
