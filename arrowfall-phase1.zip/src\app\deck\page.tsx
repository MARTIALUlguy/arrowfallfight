"use client";

import { Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { useI18n } from "@/systems/i18n";
import { getCharacter } from "@/data/characters";
import { validateDeck } from "@/data/decks";

/** Deck-builder — Phase 0 : aperçu du deck recommandé (éditeur complet en Phase 3). */
function DeckContent() {
  const { t } = useI18n();
  const params = useSearchParams();
  const mode = params.get("mode") ?? "campaign";
  const characterId = params.get("character") ?? "kael";
  const character = getCharacter(characterId);
  const validation = validateDeck(character.recommendedDeck);

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-4xl flex-col gap-6 px-6 py-10">
      <header className="flex items-center justify-between">
        <h1 className="neon-title font-display text-4xl font-bold tracking-widest">
          {t("deck.title")}
        </h1>
        <Link href="/" className="text-sm text-night-600 hover:text-white">
          ← {t("common.back")}
        </Link>
      </header>

      <p className="text-night-600">
        {t("select.title")} :{" "}
        <span className="font-semibold" style={{ color: character.accent }}>
          {t(character.nameKey)}
        </span>{" "}
        · {mode}
      </p>

      <div
        className={`rounded-lg border px-4 py-2 text-sm ${
          validation.ok
            ? "border-neon-green/60 text-neon-green"
            : "border-neon-red/60 text-neon-red"
        }`}
      >
        {t(validation.ok ? "deck.valid" : "deck.invalid")} —{" "}
        {t("deck.count", { n: character.recommendedDeck.length })}
      </div>

      <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
        {character.recommendedDeck.map((id, i) => (
          <div
            key={`${id}-${i}`}
            className="rounded-lg border border-night-700 bg-night-800/60 px-3 py-2 text-sm"
          >
            {t(`card.${id}.name`)}
          </div>
        ))}
      </div>

      <Link
        href={`/game?mode=${mode}&character=${characterId}`}
        className="rounded-lg bg-neon-blue px-6 py-3 text-center font-display text-lg font-semibold text-night-950 transition-transform hover:scale-[1.02]"
      >
        {t("common.confirm")}
      </Link>
    </main>
  );
}

export default function DeckPage() {
  return (
    <Suspense fallback={<main className="p-8 text-center">ARROWFALL</main>}>
      <DeckContent />
    </Suspense>
  );
}
