"use client";

import { Suspense, useCallback, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { actionQteLength, chooseAttack, chooseDefense, createBattleState, makeQteResult, submitAttackQte, submitDefenseQte } from "@/engine/battle";
import { chooseEasyAiAttack, chooseEasyAiDefense, submitEasyAiQte } from "@/engine/ai";
import { getAvailableActions } from "@/engine/actions";
import { getCard } from "@/data/cards";
import { getCharacter } from "@/data/characters";
import { STATUSES } from "@/data/statuses";
import { useI18n } from "@/systems/i18n";
import type { BattleState, ChosenAction, Direction, InputGrade, QteResult } from "@/types";

const DIRECTIONS: Direction[] = ["up", "right", "down", "left"];
const ARROWS: Record<Direction, string> = {
  up: "↑",
  right: "→",
  down: "↓",
  left: "←",
};

function newSequence(length: number): Direction[] {
  return Array.from({ length }, () => DIRECTIONS[Math.floor(Math.random() * DIRECTIONS.length)]);
}

function GameContent() {
  const { t } = useI18n();
  const params = useSearchParams();
  const characterId = params.get("character") ?? "kael";
  const mode = params.get("mode") ?? "campaign";
  const battleSeed = useMemo(
    () => Array.from(`${mode}:${characterId}`).reduce(
      (seed, character) => (Math.imul(seed, 31) + character.charCodeAt(0)) >>> 0,
      7,
    ),
    [characterId, mode],
  );
  const [battle, setBattle] = useState<BattleState>(() =>
    createBattleState(characterId, undefined, undefined, battleSeed),
  );
  const [sequence, setSequence] = useState<Direction[]>([]);
  const [grades, setGrades] = useState<InputGrade[]>([]);
  const player = battle.combatants[0];
  const enemy = battle.combatants[1];
  const playerCharacter = getCharacter(player.characterId);
  const enemyCharacter = getCharacter(enemy.characterId);
  const humanAttacking = battle.attackerIndex === 0;
  const humanDefending = battle.attackerIndex === 1;
  const isHumanQte = battle.phase === "ATTACK_QTE" ? humanAttacking : humanDefending;
  const isQtePhase = battle.phase === "ATTACK_QTE" || battle.phase === "DEFENSE_QTE";
  const qteLength = isQtePhase ? actionQteLength(battle, battle.phase === "DEFENSE_QTE") : 0;
  const attackActions = useMemo(() => getAvailableActions(battle, 0), [battle]);
  const defenseActions = useMemo(() => getAvailableActions(battle, 0, true), [battle]);

  useEffect(() => {
    if (battle.phase !== "ATTACK_SELECT" || battle.attackerIndex !== 1) return;
    setBattle((current) => chooseEasyAiAttack(current));
  }, [battle.phase, battle.attackerIndex]);

  useEffect(() => {
    if (battle.phase !== "DEFENSE_SELECT" || battle.attackerIndex !== 0) return;
    setBattle((current) => chooseEasyAiDefense(current));
  }, [battle.phase, battle.attackerIndex]);

  useEffect(() => {
    if (!isQtePhase) return;
    setSequence(newSequence(qteLength));
    setGrades([]);
    if (qteLength > 0 && !isHumanQte) {
      setBattle((current) => submitEasyAiQte(current, current.phase === "DEFENSE_QTE"));
      return;
    }
    if (qteLength === 0) {
      const result = makeQteResult([]);
      setBattle((current) => current.phase === "ATTACK_QTE"
        ? submitAttackQte(current, result)
        : submitDefenseQte(current, result));
    }
  }, [
    battle.phase,
    battle.attackerIndex,
    battle.chosenAttack?.cardId,
    battle.chosenAttack?.kind,
    battle.chosenDefense?.cardId,
    battle.chosenDefense?.kind,
    isHumanQte,
    isQtePhase,
    qteLength,
  ]);

  const pressDirection = useCallback((direction: Direction) => {
    if (!isQtePhase || !isHumanQte || sequence.length === 0 || grades.length >= sequence.length) return;
    const grade: InputGrade = sequence[grades.length] === direction ? "perfect" : "miss";
    const updated = [...grades, grade];
    setGrades(updated);
    if (updated.length !== sequence.length) return;
    const result: QteResult = makeQteResult(updated);
    setBattle((current) => current.phase === "ATTACK_QTE"
      ? submitAttackQte(current, result)
      : submitDefenseQte(current, result));
  }, [grades, isHumanQte, isQtePhase, sequence]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const direction: Record<string, Direction> = {
        ArrowUp: "up",
        ArrowRight: "right",
        ArrowDown: "down",
        ArrowLeft: "left",
      };
      const mapped = direction[event.key];
      if (!mapped) return;
      event.preventDefault();
      pressDirection(mapped);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [pressDirection]);

  const playAction = (action: ChosenAction, defending: boolean) => {
    setBattle((current) => defending
      ? chooseDefense(current, action)
      : chooseAttack(current, action));
  };

  const actionLabel = (action: ChosenAction, defending: boolean) => {
    if (action.kind === "basic-attack") return t("battle.basicAttack");
    if (action.kind === "basic-guard") return t("battle.basicGuard");
    if (action.kind === "ultimate") return t("battle.ultimate");
    if (action.kind === "ability") {
      return t((defending ? playerCharacter.abilityDefense : playerCharacter.abilityAttack).nameKey);
    }
    if (action.kind === "card" && action.cardId) return t(getCard(action.cardId).nameKey);
    return t("battle.noAction");
  };

  const renderActionButton = (
    action: ChosenAction,
    index: number,
    defending: boolean,
  ) => {
    const fighter = player;
    const card = action.kind === "card" && action.cardId ? getCard(action.cardId) : null;
    const cost = card?.cost;
    const isUltimate = action.kind === "ultimate";
    const ability = action.kind === "ability"
      ? (defending ? playerCharacter.abilityDefense : playerCharacter.abilityAttack)
      : null;
    const disabled = battle.phase === "BATTLE_END";
    return (
      <button
        key={`${action.kind}-${action.cardId ?? "base"}-${index}`}
        onClick={() => playAction(action, defending)}
        disabled={disabled}
        className="flex min-h-20 flex-col justify-between rounded-lg border border-night-600 bg-night-800/80 p-3 text-left transition hover:border-neon-blue hover:bg-night-700 disabled:opacity-50"
      >
        <span className="font-display font-semibold">{actionLabel(action, defending)}</span>
        <span className="mt-2 text-xs text-night-600">
          {card?.descriptionKey ? t(card.descriptionKey) : ability?.descriptionKey ? t(ability.descriptionKey) : ""}
          {cost && Object.keys(cost).length > 0 && (
            <span className="mt-1 block text-neon-blue">
              {cost.energy ? `${t("common.energy")} ${cost.energy} ` : ""}
              {cost.mana ? `${t("common.mana")} ${cost.mana} ` : ""}
              {cost.hp ? `${t("common.hp")} ${cost.hp}` : ""}
            </span>
          )}
          {isUltimate && <span className="mt-1 block text-neon-yellow">{t("battle.superReady")}</span>}
          {ability && (
            <span className="mt-1 block text-night-600">
              {t("select.cooldown", { n: fighter.cooldowns[ability.id] ?? 0 })}
            </span>
          )}
        </span>
      </button>
    );
  };

  const renderFighter = (
    fighter: typeof player,
    character: typeof playerCharacter,
    isPlayer: boolean,
  ) => (
    <section className="rounded-xl border bg-night-800/50 p-4" style={{ borderColor: `${character.accent}88` }}>
      <div className="mb-3 flex items-center justify-between gap-3">
        <div>
          <h2 className="font-display text-xl font-bold" style={{ color: character.accent }}>
            {t(character.nameKey)}
          </h2>
          <p className="text-xs text-night-600">{isPlayer ? t("common.you") : t("common.enemy")}</p>
        </div>
        <span className="text-sm">{Math.max(0, fighter.hp)} / {fighter.maxHp} {t("common.hp")}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-night-950">
        <div
          className="h-full transition-all"
          style={{
            width: `${Math.max(0, (fighter.hp / fighter.maxHp) * 100)}%`,
            backgroundColor: character.accent,
          }}
        />
      </div>
      <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
        <div>{t("common.energy")}: {fighter.energy}/{fighter.maxEnergy}</div>
        <div>{t("common.mana")}: {fighter.mana}/{fighter.maxMana}</div>
        <div>{t("common.superGauge")}: {fighter.superGauge}%</div>
      </div>
      <div className="mt-3 flex min-h-7 flex-wrap gap-2">
        {fighter.statuses.map((status) => (
          <span
            key={status.id}
            className="rounded-full border px-2 py-1 text-xs"
            style={{ borderColor: STATUSES[status.id].color, color: STATUSES[status.id].color }}
            title={t(STATUSES[status.id].descriptionKey)}
          >
            {t(STATUSES[status.id].nameKey)}{status.stacks > 1 ? ` ×${status.stacks}` : ""}
          </span>
        ))}
      </div>
    </section>
  );

  const phaseLabel = battle.phase === "ATTACK_SELECT"
    ? humanAttacking ? t("battle.playerAttack") : t("battle.enemyAttack")
    : battle.phase === "DEFENSE_SELECT"
      ? humanDefending ? t("battle.playerDefense") : t("battle.enemyDefense")
      : battle.phase === "BATTLE_END" ? t("battle.gameOver") : t("qte.go");

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-6xl flex-col gap-5 px-4 py-6 md:px-8">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="neon-title font-display text-3xl font-bold tracking-widest">{t("app.title")}</h1>
          <p className="mt-1 text-sm text-night-600">{t("common.turn", { n: battle.turn })} · {t("battle.easyAi")}</p>
        </div>
        <Link href="/" className="rounded-lg border border-night-600 px-4 py-2 text-sm hover:border-neon-blue">
          ← {t("battle.exit")}
        </Link>
      </header>

      <section className="grid gap-3 md:grid-cols-2">
        {renderFighter(player, playerCharacter, true)}
        {renderFighter(enemy, enemyCharacter, false)}
      </section>

      <section className="rounded-xl border border-night-700 bg-night-800/40 p-4">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <h2 className="font-display text-xl font-semibold">{phaseLabel}</h2>
          <span className="rounded-full border border-neon-blue/50 px-3 py-1 text-xs text-neon-blue">
            {mode}
          </span>
        </div>

        {battle.phase === "BATTLE_END" ? (
          <div className="flex flex-wrap gap-3">
            <p className="w-full text-lg">
              {battle.winner === 0 ? t("battle.youWin") : t("battle.youLose")}
            </p>
            <button
              onClick={() => setBattle(createBattleState(characterId, undefined, undefined, Date.now()))}
              className="rounded-lg bg-neon-blue px-4 py-2 font-semibold text-night-950"
            >
              {t("battle.retry")}
            </button>
            <Link href="/" className="rounded-lg border border-night-600 px-4 py-2">
              {t("menu.options")}: {t("battle.exit")}
            </Link>
          </div>
        ) : isQtePhase && isHumanQte ? (
          <div>
            <p className="mb-3 text-sm text-night-600">{t("battle.qteHint")}</p>
            <div className="mb-4 flex flex-wrap gap-2" aria-label="QTE sequence">
              {sequence.map((direction, index) => (
                <span
                  key={`${direction}-${index}`}
                  className={`flex h-11 w-11 items-center justify-center rounded-lg border text-xl ${
                    index < grades.length
                      ? grades[index] === "perfect"
                        ? "border-neon-green text-neon-green"
                        : "border-neon-red text-neon-red"
                      : index === grades.length
                        ? "border-neon-blue bg-neon-blue/10 text-white"
                        : "border-night-600 text-night-600"
                  }`}
                >
                  {ARROWS[direction]}
                </span>
              ))}
            </div>
            <p className="mb-3 text-sm text-night-600">
              {t("battle.qteProgress", { done: grades.length, total: sequence.length })}
            </p>
            <div className="grid max-w-sm grid-cols-3 gap-2">
              {(["up", "left", "down", "right"] as Direction[]).map((direction) => (
                <button
                  key={direction}
                  onClick={() => pressDirection(direction)}
                  className={`h-12 rounded-lg border border-night-600 bg-night-900 text-2xl hover:border-neon-blue ${
                    direction === "up" ? "col-start-2" : direction === "left" ? "col-start-1" : direction === "down" ? "col-start-2" : "col-start-3 row-start-2"
                  }`}
                  aria-label={direction}
                >
                  {ARROWS[direction]}
                </button>
              ))}
            </div>
          </div>
        ) : battle.phase === "ATTACK_SELECT" && humanAttacking ? (
          <div>
            <p className="mb-3 text-sm text-night-600">{t("battle.chooseAttack")}</p>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {attackActions.map((action, index) => renderActionButton(action, index, false))}
            </div>
            {player.hand.length === 0 && <p className="mt-3 text-sm text-night-600">{t("battle.handEmpty")}</p>}
          </div>
        ) : battle.phase === "DEFENSE_SELECT" && humanDefending ? (
          <div>
            <p className="mb-3 text-sm text-night-600">{t("battle.chooseDefense")}</p>
            <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
              {defenseActions.map((action, index) => renderActionButton(action, index, true))}
            </div>
          </div>
        ) : (
          <p className="text-sm text-night-600">{phaseLabel}…</p>
        )}
      </section>

      <section className="rounded-xl border border-night-700 bg-night-800/30 p-4">
        <h2 className="mb-2 font-display text-lg font-semibold">{t("battle.hand")}</h2>
        <div className="flex flex-wrap gap-2">
          {player.hand.map((cardId, index) => {
            const card = getCard(cardId);
            return (
              <span key={`${cardId}-${index}`} className="rounded border border-night-700 px-2 py-1 text-xs text-night-600">
                {t(card.nameKey)}
              </span>
            );
          })}
          {player.hand.length === 0 && <span className="text-sm text-night-600">—</span>}
        </div>
        <p className="mt-2 text-xs text-night-600">
          {t("battle.drawPile", { n: player.drawPile.length })} · {t("battle.discardPile", { n: player.discardPile.length })}
        </p>
      </section>

      <section className="rounded-xl border border-night-700 bg-night-800/30 p-4">
        <h2 className="mb-2 font-display text-lg font-semibold">{t("battle.combatLog")}</h2>
        <ol className="flex flex-col gap-1 text-sm text-night-600">
          {battle.log.slice(-6).map((entry, index) => <li key={`${entry}-${index}`}>{entry}</li>)}
        </ol>
      </section>
    </main>
  );
}

export default function GamePage() {
  return (
    <Suspense fallback={<main className="p-8 text-center">ARROWFALL</main>}>
      <GameContent />
    </Suspense>
  );
}
